#"10.32.38.230"

import socket as so
def start_server():
    s = so.socket()
    host = "10.32.38.230"
    port = 12345
    s.bind((host, port))
    s.listen()
    return s
s = start_server()

print("Väntar på att en klient ska ansluta till servern...")
conn, addr = s.accept()
print("En klient anslöt från adressen", addr)
input()
conn.close()
